
import { GoogleGenAI, Type } from "@google/genai";
import type { QuizAnswers, AIRecommendations } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    summary: {
      type: Type.STRING,
      description: "สรุปบุคลิกภาพและความถนัดของผู้ทำแบบทดสอบสั้นๆ 1-2 ประโยค เป็นภาษาไทย",
    },
    careerSuggestions: {
      type: Type.ARRAY,
      description: "แนะนำอาชีพที่เหมาะสม 3 อาชีพ เป็นภาษาไทย",
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "ชื่ออาชีพ เป็นภาษาไทย" },
          description: { type: Type.STRING, description: "คำอธิบายสั้นๆ เกี่ยวกับอาชีพนี้ เป็นภาษาไทย" },
          requiredSkills: {
            type: Type.ARRAY,
            description: "ทักษะที่จำเป็นสำหรับอาชีพนี้ 2-3 อย่าง เป็นภาษาไทย",
            items: { type: Type.STRING }
          }
        },
        required: ["name", "description", "requiredSkills"]
      }
    },
    educationSuggestions: {
      type: Type.ARRAY,
      description: "แนะนำสาขาวิชาหรือคณะที่น่าสนใจ 2-3 สาขา เป็นภาษาไทย",
      items: {
        type: Type.OBJECT,
        properties: {
          major: { type: Type.STRING, description: "ชื่อสาขาวิชา/คณะ เป็นภาษาไทย" },
          description: { type: Type.STRING, description: "คำอธิบายสั้นๆ เกี่ยวกับสาขานี้ เป็นภาษาไทย" },
          relatedCareers: {
            type: Type.ARRAY,
            description: "ตัวอย่างอาชีพที่เกี่ยวข้องกับสาขานี้ 2-3 อาชีพ เป็นภาษาไทย",
            items: { type: Type.STRING }
          }
        },
        required: ["major", "description", "relatedCareers"]
      }
    },
    activitySuggestions: {
      type: Type.ARRAY,
      description: "แนะนำกิจกรรมเสริมทักษะหรือคอร์สออนไลน์ 2-3 กิจกรรม เป็นภาษาไทย",
      items: {
        type: Type.OBJECT,
        properties: {
          type: { type: Type.STRING, description: "ประเภทของกิจกรรม (เช่น คอร์สออนไลน์, ชมรม, โครงงาน) เป็นภาษาไทย" },
          name: { type: Type.STRING, description: "ชื่อกิจกรรม/คอร์ส เป็นภาษาไทย" },
          description: { type: Type.STRING, description: "คำอธิบายว่ากิจกรรมนี้ช่วยพัฒนาทักษะด้านใด เป็นภาษาไทย" }
        },
        required: ["type", "name", "description"]
      }
    },
    userInsights: {
        type: Type.OBJECT,
        description: "วิเคราะห์และสรุปข้อมูลเชิงลึกของผู้ใช้จากคำตอบทั้งหมด ให้เป็นภาษาไทย",
        properties: {
            aptitudes: {
                type: Type.ARRAY,
                description: "สรุปความถนัดหลักๆ ของผู้ใช้ 3-4 อย่าง (เช่น 'การคิดวิเคราะห์', 'ความคิดสร้างสรรค์', 'การทำงานร่วมกับผู้อื่น')",
                items: { type: Type.STRING }
            },
            interests: {
                type: Type.ARRAY,
                description: "สรุปความสนใจหลักๆ ของผู้ใช้ 3-4 อย่าง (เช่น 'เทคโนโลยีและนวัตกรรม', 'ศิลปะและการออกแบบ', 'ธรรมชาติและสิ่งแวดล้อม')",
                items: { type: Type.STRING }
            },
            likes: {
                type: Type.ARRAY,
                description: "สรุปสิ่งที่ผู้ใช้ชอบทำจากคำตอบ 3-4 อย่าง (เช่น 'การแก้ปัญหาที่ท้าทาย', 'การช่วยเหลือสังคม', 'การเรียนรู้สิ่งใหม่ๆ')",
                items: { type: Type.STRING }
            }
        },
        required: ["aptitudes", "interests", "likes"]
    }
  },
  required: ["summary", "careerSuggestions", "educationSuggestions", "activitySuggestions", "userInsights"]
};

export const generateRecommendations = async (answers: QuizAnswers): Promise<AIRecommendations> => {
  const prompt = `
    คุณคือ 'FutureLink AI' ผู้ให้คำปรึกษาด้านอาชีพและการศึกษาที่เป็นมิตรและเชี่ยวชาญสำหรับนักเรียนไทย
    วิเคราะห์ข้อมูลจากคำตอบในแบบทดสอบต่อไปนี้:
    ${JSON.stringify(answers, null, 2)}

    จากข้อมูลนี้ กรุณาสร้างคำแนะนำที่เป็นประโยชน์ สร้างแรงบันดาลใจ และเหมาะสมกับผู้ใช้งาน
    รวมถึงวิเคราะห์และสรุปความถนัด, ความสนใจ, และสิ่งที่ผู้ใช้ชอบด้วย
    โดยให้ผลลัพธ์เป็น JSON object ที่ตรงตาม schema ที่กำหนดเท่านั้น
    คำตอบทุกอย่างใน JSON ต้องเป็นภาษาไทยทั้งหมด
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.7,
      }
    });

    const jsonText = response.text.trim();
    const result: AIRecommendations = JSON.parse(jsonText);
    return result;
    
  } catch (error) {
    console.error("Gemini API call failed:", error);
    throw new Error("Failed to generate recommendations from AI.");
  }
};